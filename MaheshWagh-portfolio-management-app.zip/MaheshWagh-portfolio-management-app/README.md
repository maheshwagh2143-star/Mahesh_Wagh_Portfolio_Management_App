# Portfolio Dashboard

A React-based portfolio management dashboard that visualizes historical portfolio performance using Excel data.

## Features
- Blog-style home page
- Portfolio performance dashboard
- Equity curve visualization
- Drawdown analysis
- Excel-based data processing
- Responsive, modern UI using MUI

## Tech Stack
- React (Vite)
- React Router
- Material UI (MUI)
- Recharts
- XLSX

## Data Source
- Historical NAV data loaded from an Excel file
- Metadata rows are dynamically skipped
- Data is cleaned and normalized before visualization

## How to Run
```bash
npm install
npm run dev
