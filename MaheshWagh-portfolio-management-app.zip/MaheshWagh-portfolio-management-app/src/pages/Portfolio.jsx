import { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Paper,
  Stack,
  CircularProgress
} from "@mui/material";

import EquityCurveChart from "../components/EquityCurveChart";
import DrawdownChart from "../components/DrawdownChart";

import { loadExcelData } from "../utils/excelParser";
import { calculateDrawdown } from "../utils/calculations";
import report from "../data/React Assignment Historical NAV Report.xlsx";

export default function Portfolio() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadExcelData(report).then(rows => {
      const processed = calculateDrawdown(rows);
      setData(processed);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
   <Box sx={{ width: "70%" }}>
  <Typography variant="h4" mb={3}>
    Portfolio Performance
  </Typography>

  <Stack
    spacing={4}
    sx={{
      width: "100%",
      maxWidth: "100%"
    }}
  >
    {/* Equity Curve */}
    <Paper
      elevation={1}
      sx={{
        p: 3,
        width: "100%"
      }}
    >
      <Typography variant="h6" mb={2}>
        Equity Curve
      </Typography>

      <Box sx={{ width: "100%", height: 350 }}>
        <EquityCurveChart data={data} />
      </Box>
    </Paper>

    {/* Drawdown */}
    <Paper
      elevation={1}
      sx={{
        p: 3,
        width: "100%"
      }}
    >
      <Typography variant="h6" mb={2}>
        Drawdown
      </Typography>

      <Box sx={{ width: "100%", height: 220 }}>
        <DrawdownChart data={data} />
      </Box>
    </Paper>
  </Stack>
</Box>

  );
}
