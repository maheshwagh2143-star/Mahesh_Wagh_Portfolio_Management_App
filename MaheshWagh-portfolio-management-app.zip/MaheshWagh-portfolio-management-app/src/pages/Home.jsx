import { Box, Typography, Grid } from "@mui/material";
import BlogCard from "../components/BlogCard";
import { blogs } from "../data/blogs";

export default function Home() {
  return (
    <Box maxWidth={1200}>
      <Typography variant="h4" mb={1}>
        Insights
      </Typography>

      <Typography color="text.secondary" mb={4}>
        Investing philosophy, portfolio updates, and long-term thinking.
      </Typography>

      <Grid container spacing={3}>
        {blogs.map(blog => (
          <Grid item xs={12} md={6} lg={4} key={blog.id}>
            <BlogCard {...blog} />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
