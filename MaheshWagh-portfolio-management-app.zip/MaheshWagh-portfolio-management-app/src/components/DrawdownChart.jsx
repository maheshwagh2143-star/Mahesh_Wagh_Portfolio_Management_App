import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

export default function DrawdownChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height="100%">

      <AreaChart data={data}>
        <XAxis
          dataKey="Date"
          tickFormatter={(date) =>
            new Date(date).toLocaleDateString("en-IN", {
              month: "short",
              year: "numeric"
            })
          }
          tick={{ fontSize: 12 }}
          minTickGap={40}
          interval="preserveStartEnd"
        />

        <YAxis />
        <Tooltip
          labelFormatter={(label) =>
            new Date(label).toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })
          }
        />

        <Area
          dataKey="drawdown"
          stroke="#DC2626"
          fill="#FEE2E2"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
