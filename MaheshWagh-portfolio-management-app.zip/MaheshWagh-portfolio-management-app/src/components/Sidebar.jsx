import {
  Box,
  Typography,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText
} from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import ShowChartIcon from "@mui/icons-material/ShowChart";
import { NavLink } from "react-router-dom";

export default function Sidebar() {
  return (
    <Box
      sx={{
        width: 240,
        borderRight: "1px solid #E5E7EB",
        height: "100vh",
        p: 2
      }}
    >
      <Typography variant="h6" mb={3}>
        Portfolio Dashboard
      </Typography>

      <List>
        <ListItemButton component={NavLink} to="/">
          <ListItemIcon>
            <HomeIcon />
          </ListItemIcon>
          <ListItemText primary="Home" />
        </ListItemButton>

        <ListItemButton component={NavLink} to="/portfolio">
          <ListItemIcon>
            <ShowChartIcon />
          </ListItemIcon>
          <ListItemText primary="Portfolio" />
        </ListItemButton>
      </List>
    </Box>
  );
}
