import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

export default function EquityCurveChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data}>
        <XAxis
          dataKey="Date"
          tickFormatter={(date) =>
            new Date(date).toLocaleDateString("en-IN", {
              month: "short",
              year: "numeric"
            })
          }
          tick={{ fontSize: 12 }}
          minTickGap={40}
          interval="preserveStartEnd"
        />

        <YAxis />
        <Tooltip
          labelFormatter={(label) =>
            new Date(label).toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })
          }
        />

        <Line
          type="monotone"
          dataKey="NAV"
          stroke="#2563EB"
          dot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
