import {
  Card,
  CardContent,
  Typography,
  Chip,
  Stack
} from "@mui/material";

export default function BlogCard({ title, date, excerpt, tag }) {
  return (
    <Card variant="outlined" sx={{ height: "100%" }}>
      <CardContent>
        <Stack spacing={1}>
          <Chip
            label={tag}
            size="small"
            sx={{ width: "fit-content" }}
          />

          <Typography variant="h6">{title}</Typography>

          <Typography variant="caption" color="text.secondary">
            {date}
          </Typography>

          <Typography variant="body2" color="text.secondary">
            {excerpt}
          </Typography>
        </Stack>
      </CardContent>
    </Card>
  );
}
