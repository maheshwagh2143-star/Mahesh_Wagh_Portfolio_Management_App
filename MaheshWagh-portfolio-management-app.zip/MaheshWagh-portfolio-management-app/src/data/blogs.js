export const blogs = [
  {
    id: 1,
    title: "The Focused Way of Investing",
    date: "Apr 03, 2024",
    excerpt:
      "FY24 brought us a 42% gain, outperforming the NIFTY. Here's how focused portfolios help long-term compounding.",
    tag: "Strategy"
  },
  {
    id: 2,
    title: "Reducing Smallcap Exposure",
    date: "Mar 18, 2024",
    excerpt:
      "We reduced smallcap exposure amid rising volatility and expensive valuations.",
    tag: "Portfolio Update"
  },
  {
    id: 3,
    title: "Understanding Drawdowns",
    date: "Feb 02, 2024",
    excerpt:
      "Drawdowns are inevitable in equity investing. The key is understanding and managing them.",
    tag: "Education"
  },
  {
    id: 4,
    title: "Why We Avoid Timing the Market",
    date: "Jan 15, 2024",
    excerpt:
      "Market timing sounds attractive, but data consistently shows why it's a losing game.",
    tag: "Philosophy"
  },
  {
    id: 5,
    title: "Year in Review: 2023",
    date: "Dec 28, 2023",
    excerpt:
      "A detailed review of portfolio performance, decisions, and lessons from 2023.",
    tag: "Annual Review"
  }
];
