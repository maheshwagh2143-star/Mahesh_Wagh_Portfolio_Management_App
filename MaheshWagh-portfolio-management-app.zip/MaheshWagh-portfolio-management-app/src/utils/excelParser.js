import * as XLSX from "xlsx";

export const loadExcelData = async (fileUrl) => {
  const buffer = await fetch(fileUrl).then(res => res.arrayBuffer());
  const workbook = XLSX.read(buffer);
  const sheet = workbook.Sheets[workbook.SheetNames[0]];

  const raw = XLSX.utils.sheet_to_json(sheet, { defval: null });

  // 1️⃣ Find header row index
  const headerIndex = raw.findIndex(
    row =>
      row["Historical Mutual Fund NAV of Quant Active Fund Gr"] === "NAV Date"
  );

  // 2️⃣ Slice actual NAV data
  const navRows = raw.slice(headerIndex + 1);

  // 3️⃣ Map to clean structure

return navRows
  .map(row => ({
    Date: new Date(
      row["Historical Mutual Fund NAV of Quant Active Fund Gr"]
        .split("-")
        .reverse()
        .join("-")
    ),
    NAV: Number(row.__EMPTY)
  }))
  .filter(r => r.Date instanceof Date && !isNaN(r.NAV));
};