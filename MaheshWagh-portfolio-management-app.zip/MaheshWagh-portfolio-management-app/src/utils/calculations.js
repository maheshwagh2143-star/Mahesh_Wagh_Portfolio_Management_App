export const calculateDrawdown = (data) => {
  let peak = data[0].NAV;
  return data.map(row => {
    peak = Math.max(peak, row.NAV);
    return {
      ...row,
      drawdown: ((row.NAV - peak) / peak) * 100
    };
  });
};
