import { Box } from "@mui/material";
import { Routes, Route, useLocation } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Home from "./pages/Home";
import Portfolio from "./pages/Portfolio";

export default function App() {
  const location = useLocation();
  const isPortfolio = location.pathname === "/portfolio";

  return (
    <Box sx={{ display: "flex", height: "100vh", width: "100vw" }}>
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <Box
        sx={{
          flex: 1,
          px: isPortfolio ? 2 : 4,
          py: 3,
          overflowY: "auto",
          backgroundColor: "#F9FAFB",
          maxWidth: isPortfolio ? "100%" : "1200px",
          margin: isPortfolio ? "0" : "0 auto"
        }}
      >
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/portfolio" element={<Portfolio />} />
        </Routes>
      </Box>
    </Box>
  );
}
